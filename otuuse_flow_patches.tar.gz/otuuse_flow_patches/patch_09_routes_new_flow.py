"""
Changes:
1. ConfirmRideBody - add optional ride_id field
2. confirm_ride - now validates ride is ACCEPTED, notifies driver, no longer reads Redis
3. New GET /chat/ride-status/{ride_id} - passenger polls this after requesting a ride
"""

path = "app/api/routes/routes.py"
with open(path) as f:
    content = f.read()

warnings = []

# 1. Add ride_id to ConfirmRideBody
old_body = '''class ConfirmRideBody(BaseModel):
    confirmed: bool'''

new_body = '''class ConfirmRideBody(BaseModel):
    confirmed: bool
    ride_id: str | None = None   # required in the new driver-first flow'''

if old_body in content:
    content = content.replace(old_body, new_body, 1)
else:
    warnings.append("ConfirmRideBody anchor not found")

# 2. Replace the entire confirm_ride function with the new flow
# Anchor: from the decorator to the last return statement in the function
old_confirm = '''@router.post("/confirm-ride")
async def confirm_ride(
    body: ConfirmRideBody,
    current_user: Annotated[User, Depends(get_current_passenger)],
    db: AsyncSession = Depends(get_db),
):
    """
    Called after the agent quotes a fare and the passenger taps Confirm.
    Creates the ride record and triggers dispatch.
    """
    if not body.confirmed:
        redis = await get_redis()
        await redis.delete(f"pending_ride:{current_user.id}")
        return {"message": "Ride cancelled"}

    # Retrieve pending ride data from Redis
    redis = await get_redis()
    raw = await redis.get(f"pending_ride:{current_user.id}")

    if not raw:
        raise HTTPException(status_code=400, detail="No pending ride to confirm. Please request a new ride.")

    ride_data = json.loads(raw)

    # Create the ride record
    from app.services.crud import create_ride
    ride = await create_ride(
        db=db,
        passenger_id=current_user.id,
        pickup_name=ride_data["pickup_name"],
        dropoff_name=ride_data["dropoff_name"],
        pickup_lat=ride_data["pickup_lat"],
        pickup_lon=ride_data["pickup_lon"],
        dropoff_lat=ride_data["dropoff_lat"],
        dropoff_lon=ride_data["dropoff_lon"],
        estimated_distance_km=ride_data["distance_km"],
        estimated_duration_minutes=ride_data["duration_minutes"],
        estimated_fare_ugx=ride_data["estimated_fare_ugx"],
    )
    await db.commit()

    # Clear pending ride
    await redis.delete(f"pending_ride:{current_user.id}")

    # Trigger dispatch - use pre-selected driver if available
    from uuid import UUID as _UUID
    _pre_driver_str = ride_data.get("pre_selected_driver_id")
    _pre_driver_id = _UUID(_pre_driver_str) if _pre_driver_str else None

    dispatched = await dispatch_service.dispatch_ride(
        ride_id=ride.id,
        db=db,
        pre_selected_driver_id=_pre_driver_id,
    )

    if not dispatched:
        return {
            "ride_id": str(ride.id),
            "message": "Ride created but no drivers are currently available. We will assign a driver as soon as one becomes available.",
        }

    return {
        "ride_id": str(ride.id),
        "message": "Ride confirmed. A driver has been alerted and will accept shortly.",
    }'''

new_confirm = '''@router.post("/confirm-ride")
async def confirm_ride(
    body: ConfirmRideBody,
    current_user: Annotated[User, Depends(get_current_passenger)],
    db: AsyncSession = Depends(get_db),
):
    """
    Called after the driver accepts and the passenger taps Confirm on the fare card.
    The ride already exists and is in ACCEPTED status at this point.
    This endpoint simply notifies the driver that the passenger is ready.
    """
    from app.models.models import Ride, RideStatus
    from uuid import UUID as _UUID

    if not body.confirmed:
        # Passenger cancelled after driver accepted - cancel the ride
        if body.ride_id:
            from datetime import datetime as _dt, timezone as _tz
            from sqlalchemy import update as _update
            await db.execute(
                _update(Ride)
                .where(Ride.id == _UUID(body.ride_id), Ride.passenger_id == current_user.id)
                .values(
                    status=RideStatus.CANCELLED,
                    cancellation_reason="passenger_cancelled_after_driver_accepted",
                    cancelled_at=_dt.now(_tz.utc),
                )
            )
            await db.commit()
        return {"message": "Ride cancelled"}

    if not body.ride_id:
        raise HTTPException(status_code=400, detail="ride_id is required")

    ride = await db.get(Ride, _UUID(body.ride_id))
    if not ride or ride.passenger_id != current_user.id:
        raise HTTPException(status_code=404, detail="Ride not found")

    if ride.status != RideStatus.ACCEPTED:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Cannot confirm: ride is in '{ride.status.value}' status. "
                "Wait for the driver to accept first."
            ),
        )

    # Notify driver that passenger confirmed and to proceed to pickup
    from app.services.notifications import notification_service
    await notification_service.notify_driver_passenger_confirmed(
        driver_user_id=ride.driver_id,
        ride_id=ride.id,
        db=db,
    )

    return {
        "ride_id": str(ride.id),
        "message": "Confirmed! Your driver is heading to your pickup point.",
    }


@router.get("/ride-status/{ride_id}")
async def get_ride_status(
    ride_id: str,
    current_user: Annotated[User, Depends(get_current_passenger)],
    db: AsyncSession = Depends(get_db),
):
    """
    Passenger polls this every 4 seconds after requesting a ride.
    Returns status and driver details once the driver accepts.
    Flutter shows the fare card only when status == 'accepted'.
    """
    from app.models.models import Ride, RideStatus, DriverProfile
    from sqlalchemy import select as _select
    from uuid import UUID as _UUID

    ride = await db.get(Ride, _UUID(ride_id))
    if not ride or ride.passenger_id != current_user.id:
        raise HTTPException(status_code=404, detail="Ride not found")

    base: dict = {
        "status": ride.status.value,
        "fare_ugx": None,
        "distance_km": None,
        "driver_name": None,
        "driver_phone": None,
        "driver_plate": None,
    }

    if ride.status in [
        RideStatus.ACCEPTED,
        RideStatus.DRIVER_ARRIVING,
        RideStatus.IN_PROGRESS,
    ] and ride.driver_id:
        driver_user = await db.get(User, ride.driver_id)
        dp_result = await db.execute(
            _select(DriverProfile).where(DriverProfile.user_id == ride.driver_id)
        )
        dp = dp_result.scalar_one_or_none()
        base.update({
            "fare_ugx": ride.estimated_fare_ugx,
            "distance_km": ride.estimated_distance_km,
            "driver_name": driver_user.name if driver_user else "Your driver",
            "driver_phone": driver_user.phone_number if driver_user else "",
            "driver_plate": (dp.plate_number if dp else None) or "—",
        })

    return base'''

if old_confirm in content:
    content = content.replace(old_confirm, new_confirm, 1)
else:
    warnings.append("confirm_ride function anchor not found in routes.py")
    if "@router.post(\"/confirm-ride\")" in content:
        print("  decorator found but full function body didn't match")

with open(path, "w") as f:
    f.write(content)

if warnings:
    print("WARNINGS:")
    for w in warnings:
        print(f"  - {w}")
else:
    print("Done - routes.py: new confirm_ride + GET /ride-status/{ride_id} added")
