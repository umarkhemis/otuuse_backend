path = "app/services/notifications.py"
with open(path) as f:
    content = f.read()

new_method = '''
    async def notify_driver_passenger_confirmed(
        self, driver_user_id: UUID, ride_id: UUID, db: AsyncSession
    ):
        """Tell the driver the passenger confirmed - proceed to pickup."""
        tokens = await self._get_user_tokens(driver_user_id, db)
        await self._send(
            tokens=tokens,
            title="Passenger Confirmed!",
            body="Your passenger confirmed the ride. Head to the pickup point now.",
            data={"type": "passenger_confirmed", "ride_id": str(ride_id)},
        )

'''

# Insert before the admin notifications section
anchor = "    # ── Admin Notifications ──"
if anchor in content:
    content = content.replace(anchor, new_method + "    # ── Admin Notifications ──", 1)
    with open(path, "w") as f:
        f.write(content)
    print("Done - notifications.py: notify_driver_passenger_confirmed added")
else:
    print("ERROR: anchor not found in notifications.py")
