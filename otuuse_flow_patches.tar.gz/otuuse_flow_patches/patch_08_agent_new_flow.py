"""
Replaces Steps 5-6 in _handle_ride_request.
Old: pre-select driver → show fare card to passenger immediately
New: create ride → dispatch to driver → return searching message + ride_id
     Fare card only appears AFTER driver accepts (passenger polls ride-status)
"""

path = "app/services/agent/agent.py"
with open(path) as f:
    content = f.read()

# The anchor is the start of Step 5 that patch_04 introduced
old = '''        # Step 5: Pre-select best driver NOW (dispatch-first approach).
        # We pre-select a driver before presenting the fare so the passenger is
        # only shown a confirmed booking, not a speculative one.
        from app.models.models import User as _UserModel
        driver = await dispatch_service.find_best_driver(
            pickup_lat=pickup_coords.latitude,
            pickup_lon=pickup_coords.longitude,
            db=db,
        )

        if not driver:
            # No drivers available - inform passenger and log for admin awareness
            logger.warning(
                "no_drivers_available",
                pickup=extracted.pickup_name,
                user_id=str(user_id),
            )
            reply = await self._generate_response(
                history=history,
                context_note=(
                    f"There are no drivers currently available near "
                    f"{extracted.pickup_name}. "
                    "Acknowledge the passenger\'s request warmly. "
                    "Apologise that no driver is available right now. "
                    "Tell them the team has been notified and ask them "
                    "to hold on or try again in a few minutes."
                ),
                user_message=user_message,
            )
            return AgentResponse(message=reply, intent=MessageIntent.RIDE_REQUEST)

        # Fetch driver contact details for the fare card
        driver_user = await db.get(_UserModel, driver.user_id)
        driver_name = driver_user.name if driver_user else "Your driver"
        driver_phone = driver_user.phone_number if driver_user else ""
        driver_plate = getattr(driver, "plate_number", None) or "—"

        # Step 6: Save pending ride with pre-selected driver
        ride_context = {
            "pickup_name": extracted.pickup_name,
            "dropoff_name": extracted.dropoff_name,
            "pickup_lat": pickup_coords.latitude,
            "pickup_lon": pickup_coords.longitude,
            "dropoff_lat": dropoff_coords.latitude,
            "dropoff_lon": dropoff_coords.longitude,
            "distance_km": route.distance_km,
            "duration_minutes": route.duration_minutes,
            "estimated_fare_ugx": route.estimated_fare_ugx,
            "pre_selected_driver_id": str(driver.user_id),
            "driver_name": driver_name,
            "driver_phone": driver_phone,
            "driver_plate": driver_plate,
        }

        from app.services.cache import get_redis
        redis = await get_redis()
        await redis.setex(
            f"pending_ride:{user_id}",
            300,   # 5 minutes to confirm
            json.dumps(ride_context),
        )

        context_note = (
            f"A driver has been found - present the fare and driver details clearly. "
            f"Route: {extracted.pickup_name} to {extracted.dropoff_name}. "
            f"Distance: {route.distance_km}km, "
            f"about {round(route.duration_minutes)} minutes. "
            f"Fare: {route.estimated_fare_ugx:,} UGX. "
            f"Driver: {driver_name}, plate number {driver_plate}. "
            "Ask the passenger to confirm to book this ride. "
            "Sound confident and warm - a real driver is waiting."
        )

        reply = await self._generate_response(
            history=history,
            context_note=context_note,
            user_message=user_message,
        )

        return AgentResponse(
            message=reply,
            intent=MessageIntent.RIDE_REQUEST,
            fare_ugx=route.estimated_fare_ugx,
            driver_name=driver_name,
            driver_phone=driver_phone,
            driver_plate=driver_plate,
        )'''

new = '''        # Step 5: Create ride record and dispatch to driver immediately.
        # The fare card is NOT shown to the passenger yet - it only appears
        # after the driver accepts. This prevents disappointed passengers.
        from app.services import crud as _crud
        from app.models.models import Ride as _Ride, RideStatus as _RS
        from sqlalchemy import update as _update, delete as _delete

        ride = await _crud.create_ride(
            db=db,
            passenger_id=user_id,
            pickup_name=extracted.pickup_name,
            dropoff_name=extracted.dropoff_name,
            pickup_lat=pickup_coords.latitude,
            pickup_lon=pickup_coords.longitude,
            dropoff_lat=dropoff_coords.latitude,
            dropoff_lon=dropoff_coords.longitude,
            estimated_distance_km=route.distance_km,
            estimated_duration_minutes=route.duration_minutes,
            estimated_fare_ugx=route.estimated_fare_ugx,
        )
        await db.commit()  # persist ride so dispatch_ride can read it

        dispatched = await dispatch_service.dispatch_ride(ride_id=ride.id, db=db)

        if not dispatched:
            # No driver found - cancel the ride and inform passenger
            from datetime import datetime as _dt2, timezone as _tz2
            await db.execute(
                _update(_Ride).where(_Ride.id == ride.id).values(
                    status=_RS.CANCELLED,
                    cancellation_reason="no_drivers_available",
                    cancelled_at=_dt2.now(_tz2.utc),
                )
            )
            await db.commit()
            logger.warning("no_drivers_available_at_dispatch",
                           pickup=extracted.pickup_name, user_id=str(user_id))
            reply = await self._generate_response(
                history=history,
                context_note=(
                    f"No drivers are currently available near {extracted.pickup_name}. "
                    "Apologise warmly and ask the passenger to try again in a few minutes."
                ),
                user_message=user_message,
            )
            return AgentResponse(message=reply, intent=MessageIntent.RIDE_REQUEST)

        # Driver has been alerted - tell the passenger to hold on.
        # The fare card will appear on the passenger\'s screen once the driver accepts.
        context_note = (
            "A driver has been found and notified. "
            "Tell the passenger warmly to hold on while the driver confirms. "
            "Keep it very brief - one sentence. "
            "Example: \'Hold on while we confirm your driver...\' "
            "Do NOT mention the fare or driver details yet."
        )
        reply = await self._generate_response(
            history=history,
            context_note=context_note,
            user_message=user_message,
        )
        return AgentResponse(
            message=reply,
            intent=MessageIntent.RIDE_REQUEST,
            ride_id=ride.id,
        )'''

if old in content:
    content = content.replace(old, new, 1)
    with open(path, "w") as f:
        f.write(content)
    print("Done - agent.py: dispatch-immediate flow with searching message")
else:
    print("ERROR: anchor not found in agent.py")
    # Try to find what's there
    if "Step 5: Pre-select" in content:
        print("  'Step 5: Pre-select' found but exact block didn't match")
    if "pending_ride:" in content:
        print("  'pending_ride:' still present in file")
