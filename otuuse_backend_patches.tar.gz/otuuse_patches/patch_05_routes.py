path = "app/api/routes/routes.py"
with open(path) as f:
    content = f.read()

warnings = []

# 1. Expand ChatResponse model
old_chat_response = '''class ChatResponse(BaseModel):
    reply: str
    intent: str
    ride_id: str | None = None
    delivery_id: str | None = None
    fare_ugx: int | None = None'''

new_chat_response = '''class ChatResponse(BaseModel):
    reply: str
    intent: str
    ride_id: str | None = None
    delivery_id: str | None = None
    fare_ugx: int | None = None
    driver_name: str | None = None
    driver_phone: str | None = None
    driver_plate: str | None = None'''

if old_chat_response in content:
    content = content.replace(old_chat_response, new_chat_response, 1)
else:
    warnings.append("ChatResponse anchor not found")

# 2. Expand send_message return to include driver fields
old_return = '''    return ChatResponse(
        reply=response.message,
        intent=response.intent.value,
        ride_id=str(response.ride_id) if response.ride_id else None,
        delivery_id=str(response.delivery_id) if response.delivery_id else None,
        fare_ugx=response.fare_ugx,
    )'''

new_return = '''    return ChatResponse(
        reply=response.message,
        intent=response.intent.value,
        ride_id=str(response.ride_id) if response.ride_id else None,
        delivery_id=str(response.delivery_id) if response.delivery_id else None,
        fare_ugx=response.fare_ugx,
        driver_name=response.driver_name,
        driver_phone=response.driver_phone,
        driver_plate=response.driver_plate,
    )'''

if old_return in content:
    content = content.replace(old_return, new_return, 1)
else:
    warnings.append("send_message return anchor not found")

# 3. Use pre_selected_driver_id in confirm_ride
old_dispatch = '''    # Trigger dispatch
    dispatched = await dispatch_service.dispatch_ride(ride_id=ride.id, db=db)'''

new_dispatch = '''    # Trigger dispatch - use pre-selected driver if available
    from uuid import UUID as _UUID
    _pre_driver_str = ride_data.get("pre_selected_driver_id")
    _pre_driver_id = _UUID(_pre_driver_str) if _pre_driver_str else None

    dispatched = await dispatch_service.dispatch_ride(
        ride_id=ride.id,
        db=db,
        pre_selected_driver_id=_pre_driver_id,
    )'''

if old_dispatch in content:
    content = content.replace(old_dispatch, new_dispatch, 1)
else:
    warnings.append("confirm_ride dispatch anchor not found")

# 4. Add passenger_phone to GET /driver/ride/active response
old_passenger = '''            "passenger_name": passenger.name if passenger else "Passenger",
        }
    }'''

new_passenger = '''            "passenger_name": passenger.name if passenger else "Passenger",
            "passenger_phone": passenger.phone_number if passenger else "",
        }
    }'''

if old_passenger in content:
    content = content.replace(old_passenger, new_passenger, 1)
else:
    warnings.append("passenger_name anchor not found in get_driver_active_ride")

with open(path, "w") as f:
    f.write(content)

if warnings:
    print("WARNINGS:")
    for w in warnings:
        print(f"  - {w}")
else:
    print("Done - routes.py patched: driver fields in ChatResponse, pre_selected_driver_id, passenger_phone")
