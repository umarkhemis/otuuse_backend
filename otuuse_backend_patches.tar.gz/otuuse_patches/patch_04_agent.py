path = "app/services/agent/agent.py"
with open(path) as f:
    content = f.read()

warnings = []

# 1. Expand AgentResponse dataclass to include driver details
old_response = '''@dataclass
class AgentResponse:
    message: str                         # text to send back to passenger
    intent: MessageIntent
    ride_id: Optional[UUID] = None
    delivery_id: Optional[UUID] = None
    fare_ugx: Optional[int] = None'''

new_response = '''@dataclass
class AgentResponse:
    message: str                         # text to send back to passenger
    intent: MessageIntent
    ride_id: Optional[UUID] = None
    delivery_id: Optional[UUID] = None
    fare_ugx: Optional[int] = None
    driver_name: Optional[str] = None    # shown on fare confirm card
    driver_phone: Optional[str] = None  # passenger can call driver on arrival
    driver_plate: Optional[str] = None  # helps passenger identify the bike'''

if old_response in content:
    content = content.replace(old_response, new_response, 1)
else:
    warnings.append("AgentResponse dataclass anchor not found")

# 2. Replace the entire Step 4 + Step 5 block in _handle_ride_request
# This is the dispatch-first change with operation hours and driver details
old_steps = '''        # Step 4: Check driver availability
        available_count = await dispatch_service.count_available_drivers(
            pickup_lat=pickup_coords.latitude,
            pickup_lon=pickup_coords.longitude,
            db=db,
        )

        if available_count == 0:
            reply = await self._generate_response(
                history=history,
                context_note=f"No drivers are currently available near {extracted.pickup_name}. Apologise and let the user know we are checking. They can try again in a few minutes.",
                user_message=user_message,
            )
            return AgentResponse(message=reply, intent=MessageIntent.RIDE_REQUEST)

        # Step 5: Save pending ride and quote fare
        # Store ride details in Redis temporarily - confirmed when user says yes
        ride_context = {
            "pickup_name": extracted.pickup_name,
            "dropoff_name": extracted.dropoff_name,
            "pickup_lat": pickup_coords.latitude,
            "pickup_lon": pickup_coords.longitude,
            "dropoff_lat": dropoff_coords.latitude,
            "dropoff_lon": dropoff_coords.longitude,
            "distance_km": route.distance_km,
            "duration_minutes": route.duration_minutes,
            "estimated_fare_ugx": route.estimated_fare_ugx,
        }

        from app.services.cache import get_redis
        redis = await get_redis()
        await redis.setex(
            f"pending_ride:{user_id}",
            300,   # 5 minutes to confirm
            json.dumps(ride_context),
        )

        context_note = (
            f"Fare quote ready. Route: {extracted.pickup_name} to {extracted.dropoff_name}. "
            f"Distance: {route.distance_km}km. "
            f"Estimated time: {round(route.duration_minutes)} minutes. "
            f"Fare: {route.estimated_fare_ugx:,} UGX. "
            f"Drivers available: {available_count}. "
            "Quote this fare clearly and ask the user to confirm. "
            "Tell them a driver will be assigned once they confirm."
        )

        reply = await self._generate_response(
            history=history,
            context_note=context_note,
            user_message=user_message,
        )

        return AgentResponse(
            message=reply,
            intent=MessageIntent.RIDE_REQUEST,
            fare_ugx=route.estimated_fare_ugx,
        )'''

new_steps = '''        # Step 4: Check operation hours (EAT = UTC+3)
        from datetime import datetime as _dt, timezone as _tz, timedelta as _td
        _eat_now = _dt.now(_tz.utc) + _td(hours=3)
        if not (settings.OPERATION_START_HOUR <= _eat_now.hour < settings.OPERATION_END_HOUR):
            reply = await self._generate_response(
                history=history,
                context_note=(
                    f"We are currently outside operating hours. "
                    f"The service runs from {settings.OPERATION_START_HOUR}:00am to "
                    f"{settings.OPERATION_END_HOUR}:00pm East Africa Time. "
                    "Apologise warmly and let the passenger know when they can book."
                ),
                user_message=user_message,
            )
            return AgentResponse(message=reply, intent=MessageIntent.RIDE_REQUEST)

        # Step 5: Pre-select best driver NOW (dispatch-first approach).
        # We find a driver before presenting the fare so the passenger is
        # only shown a confirmed booking, not a speculative one.
        from app.models.models import User as _UserModel
        driver = await dispatch_service.find_best_driver(
            pickup_lat=pickup_coords.latitude,
            pickup_lon=pickup_coords.longitude,
            db=db,
        )

        if not driver:
            # No drivers available - inform passenger and log for admin awareness
            logger.warning(
                "no_drivers_available",
                pickup=extracted.pickup_name,
                user_id=str(user_id),
            )
            reply = await self._generate_response(
                history=history,
                context_note=(
                    f"There are no drivers currently available near "
                    f"{extracted.pickup_name}. "
                    "Acknowledge the passenger\'s request warmly. "
                    "Apologise that no driver is available right now. "
                    "Tell them the team has been notified and ask them "
                    "to hold on or try again in a few minutes."
                ),
                user_message=user_message,
            )
            return AgentResponse(message=reply, intent=MessageIntent.RIDE_REQUEST)

        # Fetch driver contact details for the fare card
        driver_user = await db.get(_UserModel, driver.user_id)
        driver_name = driver_user.name if driver_user else "Your driver"
        driver_phone = driver_user.phone_number if driver_user else ""
        driver_plate = getattr(driver, "plate_number", None) or "—"

        # Step 6: Save pending ride with pre-selected driver
        ride_context = {
            "pickup_name": extracted.pickup_name,
            "dropoff_name": extracted.dropoff_name,
            "pickup_lat": pickup_coords.latitude,
            "pickup_lon": pickup_coords.longitude,
            "dropoff_lat": dropoff_coords.latitude,
            "dropoff_lon": dropoff_coords.longitude,
            "distance_km": route.distance_km,
            "duration_minutes": route.duration_minutes,
            "estimated_fare_ugx": route.estimated_fare_ugx,
            "pre_selected_driver_id": str(driver.user_id),
            "driver_name": driver_name,
            "driver_phone": driver_phone,
            "driver_plate": driver_plate,
        }

        from app.services.cache import get_redis
        redis = await get_redis()
        await redis.setex(
            f"pending_ride:{user_id}",
            300,   # 5 minutes to confirm
            json.dumps(ride_context),
        )

        context_note = (
            f"A driver has been found - present the fare and driver details clearly. "
            f"Route: {extracted.pickup_name} to {extracted.dropoff_name}. "
            f"Distance: {route.distance_km}km, "
            f"about {round(route.duration_minutes)} minutes. "
            f"Fare: {route.estimated_fare_ugx:,} UGX. "
            f"Driver: {driver_name}, plate number {driver_plate}. "
            "Ask the passenger to confirm to book this ride. "
            "Sound confident and warm - a real driver is waiting."
        )

        reply = await self._generate_response(
            history=history,
            context_note=context_note,
            user_message=user_message,
        )

        return AgentResponse(
            message=reply,
            intent=MessageIntent.RIDE_REQUEST,
            fare_ugx=route.estimated_fare_ugx,
            driver_name=driver_name,
            driver_phone=driver_phone,
            driver_plate=driver_plate,
        )'''

if old_steps in content:
    content = content.replace(old_steps, new_steps, 1)
else:
    warnings.append("dispatch-first steps anchor not found in agent.py")
    if "count_available_drivers" in content:
        print("  (count_available_drivers still present - check indentation)")

with open(path, "w") as f:
    f.write(content)

if warnings:
    print("WARNINGS:")
    for w in warnings:
        print(f"  - {w}")
else:
    print("Done - agent.py patched: dispatch-first, operation hours, driver details")
