path = "app/services/dispatch.py"
with open(path) as f:
    content = f.read()

warnings = []

# 1. Add pre_selected_driver_id param to dispatch_ride signature
old_sig = '''    async def dispatch_ride(
        self,
        ride_id: UUID,
        db: AsyncSession,
    ) -> bool:'''

new_sig = '''    async def dispatch_ride(
        self,
        ride_id: UUID,
        db: AsyncSession,
        pre_selected_driver_id: Optional[UUID] = None,
    ) -> bool:'''

if old_sig in content:
    content = content.replace(old_sig, new_sig, 1)
else:
    warnings.append("dispatch_ride signature anchor not found")

# 2. Replace the find_best_driver call with pre_selected logic
old_find = '''        # Get list of already-tried drivers for this ride (for reassignment)
        exclude_ids = await self._get_tried_driver_ids(ride_id)

        driver = await self.find_best_driver(
            pickup_lat=pickup_lat,
            pickup_lon=pickup_lon,
            db=db,
            exclude_driver_ids=exclude_ids,
        )'''

new_find = '''        # Get list of already-tried drivers for this ride (for reassignment)
        exclude_ids = await self._get_tried_driver_ids(ride_id)

        # Use pre-selected driver from agent fare quoting if available and still online
        driver = None
        if pre_selected_driver_id and pre_selected_driver_id not in exclude_ids:
            _result = await db.execute(
                select(DriverProfile).where(
                    DriverProfile.user_id == pre_selected_driver_id,
                    DriverProfile.availability == DriverAvailability.ONLINE,
                    DriverProfile.subscription_active == True,
                )
            )
            driver = _result.scalar_one_or_none()
            if not driver:
                logger.warning(
                    "pre_selected_driver_unavailable",
                    driver_id=str(pre_selected_driver_id),
                    ride_id=str(ride_id),
                )

        if not driver:
            # Fall back to scoring algorithm
            driver = await self.find_best_driver(
                pickup_lat=pickup_lat,
                pickup_lon=pickup_lon,
                db=db,
                exclude_driver_ids=exclude_ids,
            )'''

if old_find in content:
    content = content.replace(old_find, new_find, 1)
else:
    warnings.append("find_best_driver call anchor not found in dispatch.py")

with open(path, "w") as f:
    f.write(content)

if warnings:
    print("WARNINGS:")
    for w in warnings:
        print(f"  - {w}")
else:
    print("Done - dispatch.py patched: pre_selected_driver_id support added")
