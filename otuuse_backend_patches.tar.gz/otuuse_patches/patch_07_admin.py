path = "app/api/routes/admin.py"
with open(path) as f:
    content = f.read()

warnings = []

# 1. Add plate_number to OnboardDriverBody
old_body = '''class OnboardDriverBody(BaseModel):
    phone_number: str
    name: str
    initial_pin: str = Field(..., min_length=4, max_length=6)
    subscription_months: int = Field(default=1, ge=1, le=12)'''

new_body = '''class OnboardDriverBody(BaseModel):
    phone_number: str
    name: str
    initial_pin: str = Field(..., min_length=4, max_length=6)
    subscription_months: int = Field(default=1, ge=1, le=12)
    plate_number: Optional[str] = Field(default=None, max_length=20)'''

if old_body in content:
    content = content.replace(old_body, new_body, 1)
else:
    warnings.append("OnboardDriverBody anchor not found")

# 2. Pass plate_number when creating DriverProfile
old_profile = '''        invite_code=invite_code,
        onboarded_at=datetime.now(timezone.utc),'''

new_profile = '''        invite_code=invite_code,
        plate_number=body.plate_number,
        onboarded_at=datetime.now(timezone.utc),'''

if old_profile in content:
    content = content.replace(old_profile, new_profile, 1)
else:
    warnings.append("DriverProfile creation anchor not found")

# 3. Add plate_number to driver listing response
old_listing = '''            "documents_verified": profile.is_documents_verified,
        }
        for user, profile in rows
    ]'''

new_listing = '''            "documents_verified": profile.is_documents_verified,
            "plate_number": profile.plate_number,
        }
        for user, profile in rows
    ]'''

if old_listing in content:
    content = content.replace(old_listing, new_listing, 1)
else:
    warnings.append("driver listing response anchor not found")

# 4. Add admin document upload endpoint after the verify-documents endpoint
admin_doc_upload = '''

# ── Admin Document Upload ─────────────────────────────────────────────────────

@router.post("/drivers/{driver_id}/upload-document")
async def admin_upload_driver_document(
    driver_id: str,
    current_admin: Annotated[User, Depends(get_current_admin)],
    db: AsyncSession = Depends(get_db),
    doc_type: str = Form(...),   # national_id | license | registration
    file: UploadFile = File(...),
):
    """
    Admin uploads a verification document on behalf of a driver.
    Useful during in-person onboarding where admin collects documents directly.
    Re-uploading resets is_documents_verified - admin must re-verify.
    """
    from fastapi import File, Form, UploadFile

    valid_types = {"national_id", "license", "registration"}
    if doc_type not in valid_types:
        raise HTTPException(
            status_code=400,
            detail=f"doc_type must be one of {sorted(valid_types)}"
        )

    allowed_extensions = {".jpg", ".jpeg", ".png", ".pdf"}
    ext = (
        "." + file.filename.rsplit(".", 1)[-1].lower()
        if file.filename and "." in file.filename
        else ""
    )
    if ext not in allowed_extensions:
        raise HTTPException(
            status_code=400,
            detail="Only JPG, PNG, or PDF files are accepted"
        )

    profile_result = await db.execute(
        select(DriverProfile).where(DriverProfile.user_id == uuid.UUID(driver_id))
    )
    profile = profile_result.scalar_one_or_none()
    if not profile:
        raise HTTPException(status_code=404, detail="Driver profile not found")

    content_bytes = await file.read()
    from app.core.config import settings as _settings
    max_bytes = _settings.STORAGE_MAX_UPLOAD_MB * 1024 * 1024
    if len(content_bytes) > max_bytes:
        raise HTTPException(
            status_code=400,
            detail=f"File exceeds {_settings.STORAGE_MAX_UPLOAD_MB}MB limit"
        )

    from app.services.storage import storage_service
    key = await storage_service.upload(
        driver_user_id=driver_id,
        doc_type=doc_type,
        filename=file.filename,
        content=content_bytes,
    )

    column_map = {
        "national_id": "national_id_doc",
        "license": "license_doc",
        "registration": "registration_doc",
    }
    await db.execute(
        update(DriverProfile)
        .where(DriverProfile.id == profile.id)
        .values(**{column_map[doc_type]: key, "is_documents_verified": False})
    )
    await log_admin_action(
        db,
        admin_id=current_admin.id,
        action="upload_driver_document",
        target_type="driver",
        target_id=driver_id,
        details=f"doc_type={doc_type}",
    )
    await db.commit()

    return {
        "message": f"{doc_type.replace('_', ' ')} uploaded by admin. Pending verification.",
        "storage_key": key,
    }
'''

if "admin_upload_driver_document" not in content:
    # Append before the Dashboard section
    insert_before = "\n# ── Dashboard ──"
    if insert_before in content:
        content = content.replace(insert_before, admin_doc_upload + insert_before, 1)
    else:
        content = content.rstrip() + "\n" + admin_doc_upload
else:
    warnings.append("admin_upload_driver_document already present - skipped")

# 5. Add FastAPI File/Form/UploadFile imports at the top of admin.py
old_import = "from fastapi import APIRouter, Depends, HTTPException"
new_import = "from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile"

if old_import in content:
    content = content.replace(old_import, new_import, 1)
else:
    warnings.append("fastapi import anchor not found in admin.py")

with open(path, "w") as f:
    f.write(content)

if warnings:
    print("WARNINGS:")
    for w in warnings:
        print(f"  - {w}")
else:
    print("Done - admin.py patched: plate_number, driver listing, admin doc upload endpoint")
