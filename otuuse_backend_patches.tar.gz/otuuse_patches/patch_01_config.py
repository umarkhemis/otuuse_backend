path = "app/core/config.py"
with open(path) as f:
    content = f.read()

old = "    DISPATCH_AUTO_COMPLETE_STATIONARY_SECONDS: int = 120"
new = (
    "    DISPATCH_AUTO_COMPLETE_STATIONARY_SECONDS: int = 120\n"
    "\n"
    "    # Operating hours (East Africa Time = UTC+3)\n"
    "    OPERATION_START_HOUR: int = 6    # 6am EAT\n"
    "    OPERATION_END_HOUR: int = 22     # 10pm EAT"
)

if old in content:
    with open(path, "w") as f:
        f.write(content.replace(old, new, 1))
    print("Done - operation hours added to config.py")
else:
    print("ERROR: anchor not found in config.py")
