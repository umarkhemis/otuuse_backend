path = "app/models/models.py"
with open(path) as f:
    content = f.read()

old = "    is_documents_verified = Column(Boolean, default=False, nullable=False)"
new = (
    "    is_documents_verified = Column(Boolean, default=False, nullable=False)\n"
    "    plate_number = Column(String(20), nullable=True)   # vehicle plate e.g. UAX 001B"
)

if old in content:
    with open(path, "w") as f:
        f.write(content.replace(old, new, 1))
    print("Done - plate_number added to DriverProfile in models.py")
else:
    print("ERROR: anchor not found in models.py")
